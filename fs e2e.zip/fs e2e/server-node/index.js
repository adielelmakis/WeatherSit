// Require the framework and instantiate it
//jshint esversion:8
const fastify = require('fastify')({ logger: true });
const fetch = require("node-fetch");

fastify.register(require('fastify-cors'), {
  origin: true, allowedHeaders: ['Origin', 'X-Requested-With', 'Accept', 'Content-Type', 'Authorization'],
  methods: ['GET', 'PUT', 'OPTIONS', 'POST', 'DELETE'],
});

// Declare a route
fastify.get('/', async (request, reply) => {
  return { hello: 'world' };
});

fastify.post('/api/location/search/', async (request, reply) => {
  const getCityId = await fetch(`https://www.metaweather.com/api/location/search/?query=${request.body.location}`);
  const prsCityId = await getCityId.json();
  const response = await fetch(`https://www.metaweather.com/api/location/${prsCityId[0].woeid}/`);
  const data = await response.json();
  reply.send(data.consolidated_weather);
});

// Run the server!
const start = async () => {
  try {
    await fastify.listen(3000);
    console.log("server is runing");
  } catch (err) {
    fastify.log.error(err);
    process.exit(1);
  }
};
start();
